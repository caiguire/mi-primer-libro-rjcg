# PreTeXt (Miscellaneous) Support Files

### Runestone Services

The `runestone-services.xml` file contains the current version of the minimal set of JS and CSS files for providing "Runestone Services", either when hosted on a Runestone Server or when creating HTML for self-hosting.

As of 2022-02-02 the latest version can obtained with a `wget` from [https://runestone.academy/cdn/runestone/latest/webpack_static_imports.xml](https://runestone.academy/cdn/runestone/latest/webpack_static_imports.xml).